@extends("home")

@section("topbar")
    @include("layout.topbar")
@endsection


@section("sidebar")
    @include("layout.sidebar")
@endsection
@section("content")


    <h1>Dashboard</h1>

@endsection