<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col">
                <a href="https://yokohama-oht.com/?nr=true"><img class="img-fluid d-block mx-auto" src="<?php echo e(url('/img/logos/alliance-logo.png')); ?>" alt="" /></a>
            </div>
            <div class="col">
                <a href="https://www.continental-tires.com/car"><img class="img-fluid d-block mx-auto" src="<?php echo e(url('/img/logos/continental-logo.png')); ?>" alt="" /></a>
            </div>
            <div class="col">
                <a href="https://www.dunloptires.com/"><img class="img-fluid d-block mx-auto" src="<?php echo e(url('/img/logos/dunlop-logo.png')); ?>" alt="" /></a>
            </div>
            <div class="col">
                <a href="https://www.kumhotire.com/us/index.do"><img class="img-fluid d-block mx-auto" src="<?php echo e(url('/img/logos/kumho-logo.png')); ?>" alt="" /></a>
            </div>
            <div class="col">
                <a href="https://www.toyotires.com/"><img class="img-fluid d-block mx-auto" src="<?php echo e(url('/img/logos/toyo-logo.png')); ?>" alt="" /></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Ralph\OneDrive\Documents\Laravel Workspace\lomex\resources\views/includes/clients.blade.php ENDPATH**/ ?>