

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row my-3">
		<div class="col-4">
			<div class="photo-gallery">
				<div class="photos">
				<?php $__currentLoopData = $data["images"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($key == 0): ?>
					<a href="<?php echo e(url('/')); ?>/img/products/<?php echo e($image['image_source']); ?>" data-lightbox="photos">
						<img class="img-fluid" src="<?php echo e(url('/')); ?>/img/products/<?php echo e($image['image_source']); ?>">
					</a>
					<hr>
					<div class="row my-0">
					<?php else: ?>
						<div class="col-4">
							<a href="<?php echo e(url('/')); ?>/img/products/<?php echo e($image['image_source']); ?>" data-lightbox="photos">
								<img class="img-fluid" src="<?php echo e(url('/')); ?>/img/products/<?php echo e($image['image_source']); ?>" alt="">
							</a>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header">
					<h1><?php echo e($data["product"][0]["product_name"]); ?></h1>
					<h3><?php echo e($data["product"][0]["product_type"]); ?></h3>
				</div>
				<div class="card-body">
					<?php echo $data["product"][0]["product_description"]; ?>

				</div>
			</div>
		</div>
	</div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('productlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\lomex\resources\views/layout/product-details.blade.php ENDPATH**/ ?>